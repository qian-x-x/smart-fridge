abstract final class AppConfig {
  static const apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://127.0.0.1:8080',
  );

  static const connectTimeout = Duration(seconds: 8);
  static const receiveTimeout = Duration(seconds: 12);
}
